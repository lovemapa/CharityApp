# ChatApp
A module made for Chat between single or multiple users ,created in Express.js and MongoDb
